BD Dollar Exchange — Demo
Files:
- index.html  : Main demo page (single-file site)
- README.txt  : This file

How to open:
1. Download and unzip the package.
2. Double-click index.html to open in your browser (Chrome recommended).
3. Admin login: open 'Admin Login' button and use:
   username: admin
   password: 1234

Notes:
- This is a demo. All data (transactions, rate) are stored in browser localStorage.
- To reset demo data: clear browser localStorage for the page.
- For production you'll need a backend, database and secure auth.

Contact:
BD Dollar Exchange (demo)
WhatsApp: +8801916880365
